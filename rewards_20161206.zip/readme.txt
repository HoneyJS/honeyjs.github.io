文档使用对象：
web前端技术人员

页面：
http://test.bluewow.cn/rewards/

步骤：
1、在页面内找到如下几个文件引用，然后删除：
<link rel="stylesheet" href="http://test.bluewow.cn/wp-content/themes/entrance/rewards/css/style.css">
<script src="http://test.bluewow.cn/wp-content/themes/entrance/rewards/js/jquery-1.10.2.min.js"></script>
<script src="http://test.bluewow.cn/wp-content/themes/entrance/rewards/js/app.js"></script>
2、在该处引用文档包里的media.css样式文件即可
