本文档使用对象：web前端技术人员

可能涉及修改的地方：

1、蓝标数字 获奖情况
找到.section-3 .content，复制其中任意.group，每个.group对应每年的获奖情况；根据每年的获奖情况，修改替换获奖内容即可；
注意：图片宽度：287px，图片高度：188px;

2、ONESHOW 精选案例
找到.section-4 .content，复制其中任意.case-ctnr，每个.case-ctnr对应一个案例，修改href即可替换链接；
注意：图片宽度：313px，图片高度：204px;